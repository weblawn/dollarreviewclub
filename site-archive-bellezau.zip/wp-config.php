<?php
# Database Configuration
define( 'DB_NAME', 'wp_bellezau' );
define( 'DB_USER', 'bellezau' );
define( 'DB_PASSWORD', 'M0I0W6PufdALK6z89yiQ' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         ',-2iw|K 7-Ltx/sT@#K{3o&T%ILvN#E3di`fBNt27kfVU-GY;;_APk1UY};O9aHg');
define('SECURE_AUTH_KEY',  '|+DcKE6s>F1P50$L@vafi=TWK#clRTp<(w@HvvbMFIBHBt()`C{bj1evS9^:o%rq');
define('LOGGED_IN_KEY',    'e3dv>[~X|v|7}+_6><+g@Qsl#6prz17DzcfxArgff,ZO2g=LgC,]z}`7_9%]TMh$');
define('NONCE_KEY',        'T{IOk]3MdjV9D^_}[3-bHM5n_tZ[@s]vM|sKTX-Md(tUO_Jv!q%i;s!k,2A~UR/b');
define('AUTH_SALT',        'Qg?%S}n,;-WQGrc!W;L>9r1h=(@!Z}|  SW:yaPs1jGLT+Tm6+7t<*xBQ^R@W~|i');
define('SECURE_AUTH_SALT', 'NJS>=^=V]f6:$xIF):aAaB.B$`$+GZ{iC]d|)12$lIe+:WN65+@U-:CY2f9fwc@t');
define('LOGGED_IN_SALT',   '%D0f59Mc#]*Y8IY<B[#9nQ!df;i-ion{(~9bF;^VCW+NH+zJ?N-Zl-~B-G&c./( ');
define('NONCE_SALT',       '7}TX=g|FcvH<sR^Ox~klOs6pA8#<v@wKo%1:b|p5`-~g$|1}pE|m|r<lE*+4D`M^');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'bellezau' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', '8195e6a8ed15dbdda1f1419a2a351b36a0bc900b' );

define( 'WPE_FOOTER_HTML', "" );

define( 'WPE_CLUSTER_ID', '41040' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 22 );

define( 'WPE_LBMASTER_IP', '106.185.41.222' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', false );

define( 'FORCE_SSL_LOGIN', false );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'bellezau.wpengine.com', );

$wpe_varnish_servers=array ( 0 => 'pod-41040', );

$wpe_special_ips=array ( 0 => '106.185.41.222', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
